"""Grad-CAM for 1-D CNN (synopsis 5.8)."""
import numpy as np
import tensorflow as tf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import config as C


def grad_cam_1d(model, x):
    """x: (1, L, 1) preprocessed beat. Returns heat-map of length L (0-1) and probability."""
    grad_model = tf.keras.Model(model.inputs, [model.get_layer("last_conv").output, model.output])
    x = tf.convert_to_tensor(x)
    with tf.GradientTape() as tape:
        conv_out, pred = grad_model(x)
        score = pred[:, 0]
    grads = tape.gradient(score, conv_out)
    weights = tf.reduce_mean(grads, axis=1, keepdims=True)
    cam = tf.nn.relu(tf.reduce_sum(weights * conv_out, axis=-1))[0].numpy()
    cam = np.interp(np.linspace(0, len(cam) - 1, x.shape[1]), np.arange(len(cam)), cam)
    cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
    return cam, float(pred.numpy()[0, 0])


def plot_gradcam(signal, cam, prob, path=None, title=""):
    fig, ax = plt.subplots(figsize=(8, 3))
    t = np.arange(len(signal))
    ax.plot(t, signal, color="black", lw=1.2)
    ax.pcolorfast((0, len(signal)), ax.get_ylim(), cam[None, :], cmap="Reds", alpha=0.45)
    ax.set_title(f"{title} P(heart attack) = {prob:.2f}"); ax.set_xlabel("sample")
    fig.tight_layout()
    if path:
        fig.savefig(path, dpi=130); plt.close(fig)
    return fig
