"""Streamlit dashboard for the Heart Attack Detection with Optimized CNN project.
Run from this folder with: python -m streamlit run app.py
Research/education only; not for clinical decisions.
"""
from pathlib import Path
import json
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

import config as C
import data_utils as D
import explain as X
from predict import load_artifacts, predict

st.set_page_config(page_title="Heart Attack Detection | CNN", page_icon="🫀", layout="wide", initial_sidebar_state="expanded")

HISTORY_FILE = C.OUT_DIR / "prediction_history.csv"
RESULTS_FILE = C.OUT_DIR / "results.json"

st.markdown("""
<style>
:root { --pink-50: #fff5fa; --pink-100: #ffe4f0; --pink-300: #f7a8cd; --pink-500: #df4f97; --pink-700: #a92868; }
.stApp { background: linear-gradient(180deg, #fff8fc 0%, #ffffff 42%, #fff8fc 100%); }
.block-container {padding-top: 1.35rem; padding-bottom: 2.5rem; max-width: 1320px;}
.hero {padding: 1.45rem 1.6rem; border-radius: 20px; background: linear-gradient(115deg,#a92868 0%,#df4f97 52%,#f6a6cb 100%); color: white; margin-bottom: 1rem; box-shadow: 0 10px 28px rgba(169,40,104,.16); border: 1px solid #f6c3dc;}
.hero h1 {font-size: 2.05rem; margin: 0 0 .35rem 0; color: white;}
.hero p {margin: 0; color: #fff2f8; font-size: 1.02rem;}
.small-note {font-size: .88rem; color: #8c5672;}
div[data-testid="stMetric"] {background: #fff1f8; border: 1px solid #f5c6dd; padding: 13px 15px; border-radius: 15px; box-shadow: 0 3px 12px rgba(169,40,104,.05);}
div[data-testid="stMetricLabel"] p {color: #8e3764 !important;}
div[data-testid="stMetricValue"] {color: #a92868 !important;}
section[data-testid="stSidebar"] {background: linear-gradient(180deg,#fff0f7,#fff9fc); border-right: 1px solid #f4c6dc;}
section[data-testid="stSidebar"] h1, section[data-testid="stSidebar"] h2 {color:#a92868;}
.stButton > button, .stDownloadButton > button {border-radius: 12px; border: 1px solid #df4f97; background: #df4f97; color: white; font-weight: 600;}
.stButton > button:hover, .stDownloadButton > button:hover {background: #b83277; border-color: #b83277; color:white;}
[data-testid="stFileUploader"] {background:#fff5fa; border:1px dashed #e78ab8; border-radius:14px; padding: .45rem;}
hr {border-color:#f2c6dc;}
</style>
""", unsafe_allow_html=True)

banner_path = C.BASE_DIR / "assets" / "pink_ecg_banner.png"
if banner_path.exists():
    st.image(str(banner_path), use_container_width=True)
st.markdown('<div class="hero"><h1>🩷 Heart Attack Detection with Optimized CNN</h1><p>ECG heartbeat classification · model explainability · evaluation dashboard</p></div>', unsafe_allow_html=True)
st.warning("Research prototype only — this tool cannot diagnose or rule out a heart attack. Do not use predictions for medical decisions.")

with st.sidebar:
    st.title("Navigation")
    page = st.radio("Go to", ["Overview", "ECG Analysis", "Model Performance", "Results & History"], label_visibility="collapsed")
    st.divider()
    st.caption("Input format: CSV with 187 numeric ECG samples per row. An optional 188th label column is ignored.")


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}


def model_available():
    return (C.OUT_DIR / "heart_attack_cnn.keras").exists() and (C.OUT_DIR / "norm_stats.json").exists()


@st.cache_resource(show_spinner="Loading trained CNN model...")
def get_model():
    return load_artifacts()


def load_history():
    if HISTORY_FILE.exists():
        try:
            return pd.read_csv(HISTORY_FILE)
        except Exception:
            pass
    return pd.DataFrame(columns=["timestamp", "source", "beat", "prediction", "heart_attack_probability"])


def save_history(rows):
    old = load_history()
    new = pd.DataFrame(rows)
    combined = pd.concat([old, new], ignore_index=True)
    combined.to_csv(HISTORY_FILE, index=False)


def metric_value(metrics, key):
    try:
        return f"{float(metrics[key]):.1%}"
    except (KeyError, TypeError, ValueError):
        return "—"


def show_metric_image(filename, title, sample_fallback=True):
    path = C.OUT_DIR / filename
    sample = False
    if not path.exists() and sample_fallback:
        path = C.BASE_DIR / "sample_outputs_demo_run" / filename
        sample = path.exists()
    if path.exists():
        st.image(str(path), caption=(title + (" · example output from synthetic demo data" if sample else "")), use_container_width=True)
        return True
    return False


if page == "Overview":
    st.subheader("Project overview")
    st.write("This project uses a one-dimensional Convolutional Neural Network (1D-CNN) to classify individual ECG heartbeat patterns into two model classes. It also includes Grad-CAM explanations and model-evaluation outputs.")
    results = read_json(RESULTS_FILE)
    optimized = results.get("optimized", {}) if isinstance(results, dict) else {}
    baseline = results.get("baseline", {}) if isinstance(results, dict) else {}
    a, b, c, d = st.columns(4)
    a.metric("Model", "Optimized 1D-CNN")
    b.metric("Input length", f"{C.SIGNAL_LEN} samples")
    c.metric("Trained model", "Available" if model_available() else "Not found")
    d.metric("Saved predictions", str(len(load_history())))
    st.markdown("### What you can do")
    left, right = st.columns(2)
    with left:
        st.markdown("**ECG Analysis**")
        st.write("Upload a CSV or generate a demo heartbeat. View the waveform, model class, probability score, and Grad-CAM explanation.")
        st.markdown("**Results & History**")
        st.write("Review earlier predictions and download the history as a CSV report.")
    with right:
        st.markdown("**Model Performance**")
        st.write("View metrics, confusion matrices, ROC curve, training curves, and the chosen model parameters when available.")
        st.markdown("**Dataset note**")
        st.write("Synthetic demo data is only for testing the software flow. Performance claims must be based on a properly evaluated real dataset.")
    if not model_available():
        st.info("The dashboard can open without a trained model. To enable predictions, open a terminal in this project folder and run `python train.py --quick`. Then refresh this page.")
    if optimized:
        st.markdown("### Latest saved evaluation")
        cols = st.columns(4)
        for col, (label, key) in zip(cols, [("Accuracy", "accuracy"), ("Precision", "precision"), ("Recall", "recall_sensitivity"), ("F1-score", "f1")]):
            col.metric(label, metric_value(optimized, key))
        if results.get("data_source"):
            st.caption(f"Data source recorded by training: {results['data_source']}")

elif page == "ECG Analysis":
    st.subheader("ECG heartbeat analysis")
    if not model_available():
        st.error("Trained model files were not found. Run `python train.py --quick` from the project folder, then refresh the dashboard.")
        st.stop()
    model, stats = get_model()
    mode = st.radio("Choose input", ["Upload ECG CSV", "Generate demo heartbeat"], horizontal=True)
    beats = None
    source_name = ""
    if mode == "Upload ECG CSV":
        uploaded = st.file_uploader("Upload a CSV file", type=["csv"], help="Each row should contain 187 numeric ECG samples. An optional final label column is ignored.")
        if uploaded is not None:
            try:
                frame = pd.read_csv(uploaded, header=None)
                frame = frame.apply(pd.to_numeric, errors="coerce")
                if frame.isna().any().any():
                    st.error("The CSV contains non-numeric or empty cells. Please upload a CSV containing only numeric ECG values.")
                elif frame.shape[1] not in (C.SIGNAL_LEN, C.SIGNAL_LEN + 1):
                    st.error(f"Expected {C.SIGNAL_LEN} ECG values per row (or {C.SIGNAL_LEN} values plus one label column). Found {frame.shape[1]} columns.")
                else:
                    beats = frame.iloc[:, :C.SIGNAL_LEN].to_numpy(dtype=np.float32)
                    source_name = uploaded.name
                    st.success(f"Loaded {len(beats)} heartbeat row(s).")
            except Exception as exc:
                st.error(f"Could not read this CSV: {exc}")
    else:
        demo_kind = st.selectbox("Demo signal type", ["Normal-pattern demo", "MI-pattern demo"])
        if st.button("Generate and analyze heartbeat", type="primary"):
            rng = np.random.default_rng()
            st.session_state["demo_beat"] = D._make_beat(rng, demo_kind.startswith("MI"))[None, :]
            st.session_state["demo_source"] = demo_kind
        if "demo_beat" in st.session_state:
            beats = st.session_state["demo_beat"]
            source_name = st.session_state.get("demo_source", demo_kind)

    if beats is not None:
        if len(beats) > 1000:
            st.error("Please upload no more than 1,000 heartbeat rows at once.")
            st.stop()
        results, x = predict(beats, model, stats)
        st.markdown("### Prediction results")
        history_rows = []
        for i, result in enumerate(results):
            prob = float(result["probability"])
            with st.container(border=True):
                st.markdown(f"**Heartbeat {i+1}**")
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.metric("Model output", result["class"])
                    st.metric("MI-pattern probability", f"{prob:.1%}")
                    st.progress(float(np.clip(prob, 0, 1)))
                with col2:
                    fig, ax = plt.subplots(figsize=(9, 2.6))
                    ax.plot(np.arange(C.SIGNAL_LEN), np.asarray(beats[i]).ravel(), linewidth=1.6)
                    ax.set_title("ECG heartbeat waveform")
                    ax.set_xlabel("Sample index")
                    ax.set_ylabel("Amplitude")
                    ax.grid(alpha=.2)
                    fig.tight_layout()
                    st.pyplot(fig, use_container_width=True)
                    plt.close(fig)
                try:
                    cam, cam_prob = X.grad_cam_1d(model, x[i:i+1])
                    st.pyplot(X.plot_gradcam(x[i, :, 0], cam, cam_prob, title=f"Grad-CAM explanation · heartbeat {i+1}"), use_container_width=True)
                    plt.close("all")
                except Exception as exc:
                    st.info(f"Grad-CAM explanation could not be generated for this beat: {exc}")
                history_rows.append({"timestamp": datetime.now().astimezone().isoformat(timespec="seconds"), "source": source_name, "beat": i+1, "prediction": result["class"], "heart_attack_probability": prob})
        if st.button("Save these results to history", type="primary"):
            save_history(history_rows)
            st.success("Results saved to Results & History.")
        st.caption("Probability is the model's score for the MI-pattern class, not the chance that a person is having a heart attack.")

elif page == "Model Performance":
    st.subheader("Model performance and evaluation")
    results = read_json(RESULTS_FILE)
    optimized = results.get("optimized", {}) if isinstance(results, dict) else {}
    baseline = results.get("baseline", {}) if isinstance(results, dict) else {}
    if optimized:
        st.caption("Metrics below are loaded from this project's saved evaluation results.")
        cols = st.columns(4)
        for col, (label, key) in zip(cols, [("Accuracy", "accuracy"), ("Precision", "precision"), ("Recall / Sensitivity", "recall_sensitivity"), ("F1-score", "f1")]):
            col.metric(label, metric_value(optimized, key))
        cols2 = st.columns(3)
        cols2[0].metric("Specificity", metric_value(optimized, "specificity"))
        cols2[1].metric("ROC-AUC", metric_value(optimized, "roc_auc"))
        cols2[2].metric("Test true positives", str(optimized.get("tp", "—")))
        if baseline:
            with st.expander("Baseline vs optimized model metrics"):
                compare = pd.DataFrame({"Baseline CNN": baseline, "Optimized CNN": optimized})
                st.dataframe(compare, use_container_width=True)
    else:
        st.info("No training evaluation results were found yet. Run `python train.py --quick` first. Example charts may be shown below, clearly marked as synthetic-demo examples.")
    st.markdown("### Evaluation charts")
    one, two = st.columns(2)
    with one:
        show_metric_image("confusion_optimized.png", "Optimized CNN confusion matrix")
        show_metric_image("history_optimized.png", "Optimized CNN training curves")
    with two:
        show_metric_image("roc_curve.png", "ROC curve")
        show_metric_image("confusion_baseline.png", "Baseline CNN confusion matrix")
    params = read_json(C.OUT_DIR / "best_params.json")
    if params:
        st.markdown("### Selected CNN parameters")
        st.json(params)
    tuning_path = C.OUT_DIR / "tuning_trials.csv"
    if tuning_path.exists():
        st.markdown("### Hyperparameter tuning trials")
        try:
            st.dataframe(pd.read_csv(tuning_path), use_container_width=True)
        except Exception:
            st.caption("The tuning-trials file could not be read.")
    if not results:
        st.caption("Note: charts under sample_outputs_demo_run are examples from synthetic data, not evidence of real-world clinical performance.")

elif page == "Results & History":
    st.subheader("Prediction results and history")
    history = load_history()
    if history.empty:
        st.info("No saved predictions yet. Go to ECG Analysis, analyze a heartbeat, and click ‘Save these results to history’.")
    else:
        c1, c2 = st.columns(2)
        c1.metric("Saved records", len(history))
        c2.metric("Average model MI-pattern score", f"{pd.to_numeric(history['heart_attack_probability'], errors='coerce').mean():.1%}")
        st.dataframe(history.sort_values("timestamp", ascending=False), use_container_width=True, hide_index=True)
        st.download_button("Download history as CSV", data=history.to_csv(index=False).encode("utf-8"), file_name="heart_attack_prediction_history.csv", mime="text/csv", type="primary")
        if st.button("Clear saved history", type="secondary"):
            HISTORY_FILE.unlink(missing_ok=True)
            st.success("Saved prediction history cleared. Refresh this page to update the table.")
    st.markdown("### Download current evaluation results")
    if RESULTS_FILE.exists():
        st.download_button("Download evaluation results JSON", data=RESULTS_FILE.read_bytes(), file_name="heart_attack_model_results.json", mime="application/json")
    metrics_path = C.OUT_DIR / "metrics_comparison.csv"
    if metrics_path.exists():
        st.download_button("Download model metrics CSV", data=metrics_path.read_bytes(), file_name="model_metrics_comparison.csv", mime="text/csv")

st.divider()
st.caption("Educational research prototype only. ECG heartbeat labels and model scores are not a substitute for professional medical assessment.")
