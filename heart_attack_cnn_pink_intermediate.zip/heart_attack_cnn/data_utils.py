"""Data loading, validation, leakage-aware splitting and normalisation."""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_class_weight
import config as C


# ---------------------------------------------------------------- synthetic ECG
def _gauss(t, mu, sigma, amp):
    return amp * np.exp(-((t - mu) ** 2) / (2 * sigma ** 2))


def _make_beat(rng, mi: bool):
    """Create one synthetic heartbeat (P-QRS-T). MI beats get ST elevation,
    inverted T wave, pathological Q wave and a reduced R wave."""
    t = np.linspace(0, 1, C.SIGNAL_LEN)
    shift = rng.normal(0, 0.012)
    p = _gauss(t, 0.18 + shift, 0.025, rng.normal(0.15, 0.03))
    q = _gauss(t, 0.285 + shift, 0.008, -rng.normal(0.12, 0.03))
    r = _gauss(t, 0.31 + shift, 0.010, rng.normal(1.0, 0.12))
    s = _gauss(t, 0.335 + shift, 0.010, -rng.normal(0.20, 0.05))
    tw = _gauss(t, 0.58 + shift, 0.05, rng.normal(0.30, 0.06))
    beat = p + q + r + s + tw
    if mi:
        sev = rng.uniform(0.35, 1.0)                    # severity varies -> overlap with normal
        st = 0.28 * sev * (1 / (1 + np.exp(-(t - 0.36) * 60))) * (1 / (1 + np.exp((t - 0.50) * 40)))
        beat = beat + st
        beat += _gauss(t, 0.58 + shift, 0.05, -rng.normal(0.45, 0.08) * sev)   # T inversion
        beat += _gauss(t, 0.285 + shift, 0.010, -0.18 * sev)                   # deep Q
        beat -= _gauss(t, 0.31 + shift, 0.010, 0.25 * sev)                     # reduced R
    drift = rng.normal(0, 0.08) * np.sin(2 * np.pi * t * rng.uniform(0.3, 1.2) + rng.uniform(0, 6))
    noise = rng.normal(0, rng.uniform(0.02, 0.07), size=t.shape)
    beat = beat * rng.uniform(0.8, 1.2) + drift + noise
    beat = (beat - beat.min()) / (beat.max() - beat.min() + 1e-8)               # 0-1 like PTB set
    return beat.astype("float32")


def make_synthetic(n_normal=2500, n_mi=2500, seed=C.SEED):
    rng = np.random.default_rng(seed)
    X = np.stack([_make_beat(rng, False) for _ in range(n_normal)] +
                 [_make_beat(rng, True) for _ in range(n_mi)])
    y = np.array([0] * n_normal + [1] * n_mi)
    return X, y


# ---------------------------------------------------------------- loading
def load_dataset():
    """Return (X, y, source). Uses the real PTB heartbeat CSVs when present,
    otherwise falls back to the built-in synthetic ECG generator so the
    project always runs out-of-the-box."""
    if C.NORMAL_CSV.exists() and C.ABNORMAL_CSV.exists():
        n = pd.read_csv(C.NORMAL_CSV, header=None).values
        a = pd.read_csv(C.ABNORMAL_CSV, header=None).values
        df = np.vstack([n, a])
        X, y = df[:, :C.SIGNAL_LEN].astype("float32"), df[:, -1].astype(int)
        # PTB files already carry labels, but force 0 = normal, 1 = MI from file origin
        y = np.concatenate([np.zeros(len(n), int), np.ones(len(a), int)])
        return X, y, "PTB Diagnostic ECG heartbeats (real data)"
    print("[!] Real dataset not found in data/ -> using SYNTHETIC ECG data (demo mode).")
    X, y = make_synthetic()
    return X, y, "Synthetic ECG (demo mode)"


def validate(X, y):
    """Quality checks from synopsis 5.1: NaNs, duplicates, shape, class balance."""
    report = {"raw_records": int(len(X))}
    ok = ~np.isnan(X).any(axis=1)
    report["removed_nan"] = int((~ok).sum())
    X, y = X[ok], y[ok]
    _, uniq_idx = np.unique(np.round(X, 5), axis=0, return_index=True)   # drop duplicates
    uniq_idx = np.sort(uniq_idx)
    report["removed_duplicates"] = int(len(X) - len(uniq_idx))
    X, y = X[uniq_idx], y[uniq_idx]
    report["final_records"] = int(len(X))
    report["class_counts"] = {"normal(0)": int((y == 0).sum()), "heart_attack(1)": int((y == 1).sum())}
    return X, y, report


# ---------------------------------------------------------------- split + normalise
def split_and_normalise(X, y):
    X_tmp, X_te, y_tmp, y_te = train_test_split(
        X, y, test_size=C.TEST_SIZE, stratify=y, random_state=C.SEED)
    val_frac = C.VAL_SIZE / (1 - C.TEST_SIZE)
    X_tr, X_va, y_tr, y_va = train_test_split(
        X_tmp, y_tmp, test_size=val_frac, stratify=y_tmp, random_state=C.SEED)

    mean, std = float(X_tr.mean()), float(X_tr.std() + 1e-8)       # TRAIN statistics only
    norm = lambda a: ((a - mean) / std)[..., None].astype("float32")  # add channel axis
    data = dict(X_train=norm(X_tr), y_train=y_tr, X_val=norm(X_va), y_val=y_va,
                X_test=norm(X_te), y_test=y_te)
    return data, {"mean": mean, "std": std}


def class_weights(y):
    w = compute_class_weight("balanced", classes=np.array([0, 1]), y=y)
    return {0: float(w[0]), 1: float(w[1])}


def preprocess_new(X, stats):
    """Same preprocessing used in training, for new inputs (synopsis 5.9)."""
    X = np.asarray(X, dtype="float32")
    if X.ndim == 1:
        X = X[None, :]
    if X.shape[1] != C.SIGNAL_LEN:               # pad / crop to fixed length
        out = np.zeros((X.shape[0], C.SIGNAL_LEN), "float32")
        m = min(C.SIGNAL_LEN, X.shape[1]); out[:, :m] = X[:, :m]; X = out
    lo, hi = X.min(1, keepdims=True), X.max(1, keepdims=True)
    if hi.max() > 1.0001 or lo.min() < -0.0001:   # scale each beat to 0-1 like training data
        X = (X - lo) / (hi - lo + 1e-8)
    return ((X - stats["mean"]) / stats["std"])[..., None].astype("float32")
