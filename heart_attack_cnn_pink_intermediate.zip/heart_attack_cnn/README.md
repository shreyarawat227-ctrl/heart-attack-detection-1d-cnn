# Heart Attack Detection with Optimized CNN

Mini project based on the synopsis *"Heart Attack Detection"* (BCA AI & DS, Graphic Era).
A 1-D Convolutional Neural Network classifies single ECG heartbeats as **Normal** or **Heart-attack (MI) pattern**,
with a validation-based hyper-parameter optimisation stage, full evaluation, Grad-CAM explainability and a prediction app.

> Research prototype only - NOT a medical diagnosis tool.

## 1. Setup (one time)
```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
```
Python 3.9 - 3.12 recommended. No GPU needed (CPU trains in a few minutes).

## 2. Run
```bash
python train.py --quick        # ~2 min demo run
python train.py                # full run (12 search trials, 40 epochs max)
python predict.py --demo --gradcam
streamlit run app.py           # optional web interface
```
The project works immediately using a built-in **synthetic ECG generator** (demo mode).

### Using the real dataset (recommended for final submission)
1. Download the Kaggle dataset **"ECG Heartbeat Categorization Dataset"** (Fazeli et al.; PTB Diagnostic ECG Database part).
2. Copy `ptbdb_normal.csv` and `ptbdb_abnormal.csv` into the `data/` folder.
3. Run `python train.py` - it detects the files automatically (normal = 0, myocardial infarction = 1).

## 3. Dashboard features
The Streamlit interface (`app.py`) includes:
- **Overview:** project summary, model availability, and latest saved evaluation metrics.
- **ECG Analysis:** upload a CSV (187 numeric samples per row, optional 188th label column), generate a demo heartbeat, view the waveform, class output, model score, and Grad-CAM explanation.
- **Model Performance:** saved accuracy, precision, recall/sensitivity, specificity, F1-score, ROC-AUC, confusion matrices, ROC/training curves, and tuning results when available.
- **Results & History:** save prediction rows locally, review them, and download history and evaluation reports as CSV/JSON.

Prediction history is stored locally at `outputs/prediction_history.csv`. Performance charts in `sample_outputs_demo_run/` are example outputs generated with synthetic data; they must not be presented as real-world clinical performance.

## 4. Project structure (mapped to the synopsis)
| File | Synopsis section |
|---|---|
| `config.py` | Settings, search space (Table 5.1) |
| `data_utils.py` | 5.1/5.2 quality checks, duplicate removal, stratified split, train-only normalisation, class weights |
| `model.py` | 5.3 baseline / tunable CNN (Conv -> BN -> ReLU -> Pool ... GAP -> Dropout -> Sigmoid) |
| `tune.py` | 5.5 random-search optimisation, objective = validation F1 (test set untouched) |
| `train.py` | Full pipeline: baseline -> optimise -> final train (Adam, BCE, early stopping) -> test |
| `evaluate.py` | 5.7 accuracy, precision, recall, specificity, F1, ROC-AUC, confusion matrix, curves |
| `explain.py` | 5.8 Grad-CAM for 1-D CNN |
| `predict.py`, `app.py` | 5.9 prediction on new input with probability |

## 5. Outputs (`outputs/`)
`heart_attack_cnn.keras`, `best_params.json`, `tuning_trials.csv`, `metrics_comparison.csv`, `results.json`,
`history_*.png`, `confusion_*.png`, `roc_curve.png`, `gradcam_*.png` (TP/TN/FP/FN examples).
`sample_outputs_demo_run/` holds results from a quick run on synthetic data.

## 6. Known limitations (state these in your report)
- Synthetic data gives optimistic scores; only real-data results should be reported.
- PTB heartbeat CSVs have no patient IDs, so a patient-level split is not possible; the same patient's beats may
  appear in train and test, which can inflate accuracy. Mention this honestly (synopsis 2.4 / 4.3).
- Exact numbers must come from your own run on the real dataset.

## Project difficulty and interface
- **Suggested academic difficulty:** 5–6/10 (intermediate BCA-level project).
- **Core features retained:** optimized 1D-CNN inference, 187-value ECG CSV upload, demo heartbeat generation, waveform view, Grad-CAM explanation, evaluation charts, and prediction history/export.
- **Pink theme:** the Streamlit dashboard uses a soft pink clinical-style theme and a local ECG banner stored in `assets/pink_ecg_banner.png`.
- **Important:** the included demo data and sample metrics are for software demonstration only. This project is not a medical diagnostic tool.

