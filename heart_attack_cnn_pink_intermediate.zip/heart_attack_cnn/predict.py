"""Predict on new ECG heartbeat(s).

Usage:
    python predict.py --csv my_beats.csv        # rows of 187 values (optional label column ignored)
    python predict.py --demo                    # classify a synthetic normal & MI beat
"""
import os, json, argparse
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
import numpy as np
import pandas as pd
import tensorflow as tf
import config as C
import data_utils as D
import explain as X


def load_artifacts():
    model = tf.keras.models.load_model(C.OUT_DIR / "heart_attack_cnn.keras")
    stats = json.load(open(C.OUT_DIR / "norm_stats.json"))
    return model, stats


def predict(beats, model=None, stats=None):
    if model is None:
        model, stats = load_artifacts()
    x = D.preprocess_new(beats, stats)
    p = model.predict(x, verbose=0).ravel()
    return [{"probability": float(v), "class": "Heart attack (MI) pattern" if v >= C.THRESHOLD
             else "Normal"} for v in p], x


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv"); ap.add_argument("--demo", action="store_true")
    ap.add_argument("--gradcam", action="store_true")
    a = ap.parse_args()
    model, stats = load_artifacts()
    if a.demo:
        rng = np.random.default_rng(7)
        beats = np.stack([D._make_beat(rng, False), D._make_beat(rng, True)])
    elif a.csv:
        df = pd.read_csv(a.csv, header=None).values
        beats = df[:, :C.SIGNAL_LEN] if df.shape[1] > C.SIGNAL_LEN else df
    else:
        ap.error("give --csv FILE or --demo")
    res, x = predict(beats, model, stats)
    for i, r in enumerate(res):
        print(f"Beat {i+1}: {r['class']}  (P={r['probability']:.3f})")
        if a.gradcam:
            cam, p = X.grad_cam_1d(model, x[i:i+1])
            X.plot_gradcam(x[i, :, 0], cam, p, C.OUT_DIR / f"predict_gradcam_{i+1}.png")
    print("\nNOTE: research prototype - not a medical diagnosis.")
