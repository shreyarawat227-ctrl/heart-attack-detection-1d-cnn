"""1-D CNN builder (baseline + tunable) following synopsis section 5.3."""
import os
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
import config as C


def build_cnn(n_blocks=2, filters=16, kernel_size=5, dropout=0.3,
              learning_rate=1e-3, input_len=C.SIGNAL_LEN, **_ignored):
    inp = layers.Input(shape=(input_len, 1))
    x = inp
    for i in range(n_blocks):
        f = filters * (2 ** min(i, 2)) if i else filters      # widen with depth
        x = layers.Conv1D(f, kernel_size, padding="same", name=f"conv{i+1}")(x)
        x = layers.BatchNormalization()(x)
        x = layers.ReLU(name=f"relu{i+1}")(x)
        if i < n_blocks - 1:
            x = layers.MaxPooling1D(2)(x)
    # name the last activation so Grad-CAM can find it
    x = layers.Identity(name="last_conv")(x)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dropout(dropout)(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    model = models.Model(inp, out)
    model.compile(optimizer=optimizers.Adam(learning_rate),
                  loss="binary_crossentropy",
                  metrics=["accuracy", tf.keras.metrics.AUC(name="auc")])
    return model
