"""Central configuration for the Heart Attack Detection (Optimized CNN) project."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUT_DIR = BASE_DIR / "outputs"
OUT_DIR.mkdir(exist_ok=True)
DATA_DIR.mkdir(exist_ok=True)

# Real dataset files (Kaggle: "ECG Heartbeat Categorization Dataset", PTB Diagnostic ECG DB)
# Each row = 187 samples of one heartbeat + 1 label column (last). Normal -> 0, MI/abnormal -> 1
NORMAL_CSV = DATA_DIR / "ptbdb_normal.csv"
ABNORMAL_CSV = DATA_DIR / "ptbdb_abnormal.csv"

SIGNAL_LEN = 187
SEED = 42

# Split (train / val / test)
TEST_SIZE = 0.15
VAL_SIZE = 0.15

# Training
MAX_EPOCHS = 40
EARLY_STOP_PATIENCE = 6
THRESHOLD = 0.5            # predefined decision rule (fixed before test evaluation)

# Hyper-parameter search (random search, objective = validation F1)
N_TRIALS = 12
TUNE_EPOCHS = 15

# Baseline CNN (reference point, as in synopsis section 5.3)
BASELINE_PARAMS = dict(
    n_blocks=2, filters=16, kernel_size=5,
    dropout=0.30, learning_rate=1e-3, batch_size=64,
)

# Search space (synopsis Table 5.1)
SEARCH_SPACE = dict(
    n_blocks=[2, 3, 4],
    filters=[16, 32, 64, 128],
    kernel_size=[3, 5, 7],
    dropout=[0.2, 0.3, 0.4, 0.5],
    learning_rate=[1e-4, 3e-4, 1e-3, 3e-3, 1e-2],
    batch_size=[16, 32, 64],
)
